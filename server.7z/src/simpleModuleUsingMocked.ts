import * as math from './simpleModuleToMock';

export const add3 = (a: number) => math.add(a, 3);
export const subtract3 = (a: number) => math.subtract(a, 3);
export const multiply3 = (a: number) => math.multiply(a, 3);
export const divide3 = (a: number) => math.divide(a, 3);
