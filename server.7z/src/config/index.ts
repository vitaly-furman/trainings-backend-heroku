import * as env from 'env-var';
import './dotenv';

const config = {
    service: {
        port: env.get('PORT').required().asPortNumber(),
    },
    mongo: {
        uri: env.get('MONGO_URI').required().asUrlString(),
        workersCollectionName: env.get('MONGO_WORKERS_COLLECTION_NAME').required().asString(),
        trainingsCollectionName: env.get('MONGO_TRAININGS_COLLECTION_NAME').required().asString(),
    },
};

export default config;
