import * as Joi from '@hapi/joi';

// GET /api/trainings
export const getTrainingRequestSchema = Joi.object({
    query: {},
    body: {},
    params: {},
});


// POST /api/workers/
export const createTrainingRequestSchema = Joi.object({
    body: {
        name: Joi.string().required(),
    },
    query: {},
    params: {},
});
