export interface ITraining {
    name: string;
}
