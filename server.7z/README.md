## TS Template

### Setup:

1. Install recommended VS Code extentions:

    - eslint "dbaeumer.vscode-eslint"
    - prettier "esbenp.prettier-vscode"

2. Install node dependencies ("npm install")
3. Everything should work now
